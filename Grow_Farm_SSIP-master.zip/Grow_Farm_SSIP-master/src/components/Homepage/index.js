import React from 'react'
import "./style.css"

function Homepage() {
  return (
    <>
    <div id='homepaggg' style={{marginTop:"100px"}}>Homepage</div>
    </>
  )
}

export default Homepage