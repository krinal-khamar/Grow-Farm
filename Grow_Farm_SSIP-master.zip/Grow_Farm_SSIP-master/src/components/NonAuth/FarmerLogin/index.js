import React from 'react'
import "./Style.css"

function FarmerLogin() {
  return (
    <>
    <div id='header1test2' >
    <div style={{marginTop:"100px"}}>FarmerLogin</div>
<form id='Floginf1'>
  <h3>Login Here</h3> 
  <label className="Fllable" for="username">Mobile Number</label>
  <input className='Flinput' type="text" placeholder="9876543210" id="username"/>

  <label className="Fllable" for="password">Unique Id</label>
  <input className='Flinput' type="password" placeholder="ba7816bf8f01cfea414140de5dae2223b00" id="password"/>
  <label className="Fllable" for="password">Password</label>
  <input className='Flinput' type="password" placeholder="Abcd@1234" id="password"/>

  <button>Log In</button>
</form>
</div>
    </>
  )
}

export default FarmerLogin