import React from 'react'
import "./style.css"

function GovermentLogin() {
  return (
    <>
    <div id='header1test2' >
    <div style={{marginTop:"100px"}}>FarmerLogin</div>
<form id='Floginf1Gl'>
  <h4 id='GlmaintitleGl'>Goverment Login</h4> 

  <label className="Fllable" for="password">User Id</label>
  <input className='Flinput' type="password" placeholder="ba7816bf8f01cfea414140de5dae2223b00" id="password"/>
  <label className="Fllable" for="password">Password</label>
  <input className='Flinput' type="password" placeholder="Abcd@1234" id="password"/>

  <button>Log In</button>
</form>
</div>
    </>
  )
}

export default GovermentLogin