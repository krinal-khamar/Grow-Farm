import React from 'react'
import {useState} from "react";
import "./Style.css"
import {useNavigate} from 'react-router-dom';
import * as axios from 'axios';

function FarmerRegistration() {

  const navigate = useNavigate();
  const url = "https://bgrowfarmapi/postapi"
  const [data , setData] = useState({
    Name : "",
    Gender: "",
    Category : "",
    Qualification : "",
    Physicallyhandi : "",
    Farmertype : "",
    Rationcard : "",
    Rationcardnum : "",
    Dateofbirth : "",
    Emailid : "",
    Mobilenum : "",
    Adharcard : "",
    
    State : "",
    District : "",
    Taluka : "",
    Village : "",
    Whichcrops : "",
    Harvestingtechnique : "",
    addanothercrop : "",
    Availableirrigation : "",
    Memofcoop : "",
    Selcatcoop : "",
    Namecoopsoci : "",
    Addcoopsoci : "",
    
    Bankname : "",
    Ifsccode : "",
    Accnumber : "",
    confaccnum : "",
    Uploadaadhcard : "",
    Uploadrationcard : "",
    Createpass : "",
    Confirmpass : "",


  })

function submit(e){
e.preventDefault();
navigate('/ThankspageEnrollment');
axios.post(url ,{
  Name : data.Name,
  Gender: data.Gender,
  Category : data.Category,
  Qualification : data.Qualification,
  Physicallyhandi : data.Physicallyhandi,
  Farmertype : data.Farmertype,
  Rationcard : data.Rationcard,
  Rationcardnum : data.Rationcardnum,
  Dateofbirth : data.Dateofbirth,
  Emailid : data.Emailid,
  Mobilenum : data.Mobilenum,
  Adharcard : data.Adharcard,


  State : data.State,
  District : data.District,
  Taluka : data.Taluka,
  Village : data.Village,
  Whichcrops : data.Whichcrops,
  Harvestingtechnique : data.Harvestingtechnique,
  addanothercrop : data.addanothercrop,
  Availableirrigation : data.Availableirrigation,
  Memofcoop : data.Memofcoop,
  Selcatcoop : data.Selcatcoop,
  Namecoopsoci : data.Namecoopsoci,
  Addcoopsoci : data.Addcoopsoci,
  
  Bankname : data.Bankname,
  Ifsccode : data.Ifsccode,
  Accnumber : data.Accnumber,
  confaccnum : data.confaccnum,
  Uploadaadhcard : data.Uploadaadhcard,
  Uploadrationcard : data.Uploadrationcard,
  Createpass : data.Createpass,
  Confirmpass : data.Confirmpass,

})
.then(res => {
  console.log(res.data)
})
}

 function handle(e) {
  const newdata = {...data}
  newdata[e.target.id] = e.target.value
  setData(newdata)
  console.log(newdata)
 }


  return (
    <>
    <div id='header1test' style={{marginTop:"100px"}}>Farmer Registration form</div>

    
    <div  id="Efmainform" style={{ textAlign : "center"}} >

<form action="https://bgrowfarmapi/postapi" method="post" onSubmit={(e)=> submit(e)}>
  <h6>Prsonal Information</h6>
  <input onChange={(e) => handle(e)} id="Name" value={data.Name} placeholder="Name" type="text"></input><br />
  <input onChange={(e) => handle(e)} id="Gender" value={data.Gender} placeholder="Gender" type="text"></input><br />
  <input onChange={(e) => handle(e)} id="Category" value={data.Category} placeholder="Category" type="text"></input><br />
  <input onChange={(e) => handle(e)} id="Qualification" value={data.Qualification} placeholder="Qualification" type="text"></input><br />
  <input onChange={(e) => handle(e)} id="Physicallyhandi"  value={data.Physicallyhandi} placeholder="Physically handicafe" type="number"></input><br />
  <input onChange={(e) => handle(e)} id="Farmertype" value={data.Farmertype} placeholder="Farmer type" type="number"></input><br />
  <input onChange={(e) => handle(e)} id="Rationcard" value={data.Rationcard} placeholder="Ration card category" type="number"></input><br />
  <input onChange={(e) => handle(e)} id="Rationcardnum" value={data.Rationcardnum} placeholder="Ration card number" type="number"></input><br />
  <input onChange={(e) => handle(e)} id="Dateofbirth" value={data.Dateofbirth} placeholder="Date of birth" type="number"></input><br />
  <input onChange={(e) => handle(e)} id="Emailid" value={data.Emailid} placeholder="Email ID" type="number"></input><br />
  <input onChange={(e) => handle(e)} id="Mobilenum" value={data.Mobilenum} placeholder="Mobile number" type="number"></input><br />
  <input onChange={(e) => handle(e)} id="Adharcard" value={data.Adharcard} placeholder="Adhar card" type="number"></input><br />
  <h6>Farm location and other details</h6>
  <input onChange={(e) => handle(e)} id="State" value={data.State} placeholder="State" type="text"></input><br />
  <input onChange={(e) => handle(e)} id="District" value={data.District} placeholder="District" type="text"></input><br />
  <input onChange={(e) => handle(e)} id="Taluka" value={data.Taluka} placeholder="Taluka" type="text"></input><br />
  <input onChange={(e) => handle(e)} id="Village" value={data.Village} placeholder="Village" type="text"></input><br />
  <input onChange={(e) => handle(e)} id="Whichcrops"  value={data.Whichcrops} placeholder="Which type of crops you saw ?" type="number"></input><br />
  <input onChange={(e) => handle(e)} id="Harvestingtechnique" value={data.Harvestingtechnique} placeholder="Which type of Harvesting technique you use for this crop ?
" type="number"></input><br />
  <input onChange={(e) => handle(e)} id="addanothercrop" value={data.Addanothercrop} placeholder="Add another crop" type="number"></input><br />
  <input onChange={(e) => handle(e)} id="Availableirrigation" value={data.Availableirrigation} placeholder="Available sources of irrigation" type="number"></input><br />
  <input onChange={(e) => handle(e)} id="Memofcoop" value={data.Memofcoop} placeholder="Are you member of any cooperative 
society ?
" type="number"></input><br />
  <input onChange={(e) => handle(e)} id="Selcatcoop" value={data.Selcatcoop} placeholder="Select category of cooperative
society" type="number"></input><br />
  <input onChange={(e) => handle(e)} id="Namecoopsoci" value={data.Namecoopsoci} placeholder="Name of cooperative society" type="number"></input><br />
  <input onChange={(e) => handle(e)} id="Addcoopsoci" value={data.Addcoopsoci} placeholder="Add another cooperative society" type="number"></input><br />
  {/* <input onChange={(e) => handle(e)} id="Closing_rank" value={data.Closing_rank} placeholder="Closing_rank" type="number"></input><br /> */}
  <h6>Bank Details</h6>
  <input onChange={(e) => handle(e)} id="Bankname" value={data.Bankname} placeholder="Bank name" type="text"></input><br />
  <input onChange={(e) => handle(e)} id="Ifsccode" value={data.Ifsccode} placeholder="IFSC code " type="text"></input><br />
  <input onChange={(e) => handle(e)} id="Accnumber" value={data.Accnumber} placeholder="Account number" type="text"></input><br />
  <input onChange={(e) => handle(e)} id="confaccnum" value={data.Confaccnum} placeholder="Confirm your account number " type="text"></input><br />
  <input onChange={(e) => handle(e)} id="Uploadaadhcard"  value={data.Uploadaadhcard} placeholder="Upload aadhar card" type="number"></input><br />
  <input onChange={(e) => handle(e)} id="Uploadrationcard" value={data.Uploadrationcard} placeholder="Upload Ration card" type="number"></input><br />
  <h6>Authentication Details</h6>
  <input onChange={(e) => handle(e)} id="Createpass" value={data.Createpass} placeholder="Create Password" type="text"></input><br />
  <input onChange={(e) => handle(e)} id="Confirmpass" value={data.Confirmpass} placeholder="Confirm password" type="text"></input><br />
  <button>Submit</button>
</form>
    </div>
    </>
  )
}

export default FarmerRegistration