import { Link, useMatch, useResolvedPath } from "react-router-dom"
import "./style.css"
import Logo1 from "../../assets/logo.svg";
import CardMedia from '@mui/material/CardMedia';

export default function Navbar() {
  return (
    <>
  

<nav class="navbar fixed-top  navbar-expand-lg navbar-light bg-light" id="nav">
<div class="container-fluid">
<Link to="/Homepage" className="site-title">
        
        <CardMedia
          component="img"
          height="55"
          image={Logo1}
          alt="Career Insights"
          className='mainlogo1'
        />
        <span style={{color:"#228944"}}>G</span>
        row <spane style={{color:"#228944"}}>&nbsp;F</spane> arm
        </Link>
  <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
    <span class="navbar-toggler-icon"></span>
  </button>
  <div class="collapse navbar-collapse" id="navbarSupportedContent">
    <ul class="navbar-nav me-auto mb-2 mb-lg-0">
    <CustomLink to="/FarmerRegistration">Farmer Registration</CustomLink>
        <CustomLink to="/FarmerLogin">Farmer login</CustomLink>
        <CustomLink to="/GovermentLogin">Goverment login</CustomLink>
    
    </ul>
  </div>
</div>
</nav>
</>
  )
}

function CustomLink({ to, children, ...props }) {
  const resolvedPath = useResolvedPath(to)
  const isActive = useMatch({ path: resolvedPath.pathname, end: true })

  return (
    <li className={isActive ? "active" : ""}>
      <Link to={to} {...props}>
        {children}
      </Link>
    </li>
  )
}