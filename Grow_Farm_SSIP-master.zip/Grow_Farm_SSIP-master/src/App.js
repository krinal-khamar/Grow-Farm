import './App.css';
import Navbar from "./components/Navbar"
import Footer from "./components/Footer"
import { Route, Routes } from 'react-router-dom';
import FarmerLogin from "./components/NonAuth/FarmerLogin"
import FarmerRegistration from "./components/NonAuth/FarmerRegistration"
import GovermentLogin from "./components/NonAuth/GovermentLogin"
import Homepage from "./components/Homepage"
import Enrollmentform from "./components/Auth/Enrollmentform"
import Placementform from "./components/Auth/Placementform"
import ThankspageEnrollment from "./components/Auth/ThankspageEnrollment"

function App() {
  return (
    <div className="App">
      <Navbar/>
      <Routes>
      <Route path='/Homepage' element={<Homepage/>}/>
        <Route path="/FarmerRegistration" element={<FarmerRegistration/>}/>
        <Route path='/FarmerLogin' element={<FarmerLogin/>}/>
        <Route path='/GovermentLogin' element={<GovermentLogin/>}/>
        <Route path='/Enrollmentform' element={<Enrollmentform/>}/>
        <Route path='/Placementform' element={<Placementform/>}/>
        <Route path='/ThankspageEnrollment' element={<ThankspageEnrollment/>}/>
      </Routes>
      <Footer/>

    
    </div>
  );
}

export default App;
